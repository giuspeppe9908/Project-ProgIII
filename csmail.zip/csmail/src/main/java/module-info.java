module com.example.csmail {
    requires javafx.controls;
    requires javafx.fxml;
    requires json.simple;
    requires com.fasterxml.jackson.core;
    requires controlsfx;
    requires com.google.gson;


    opens com.example.csmail to javafx.fxml;
    exports com.example.csmail;
    exports com.example.csmail.Server;
    opens com.example.csmail.Server to javafx.fxml;
    exports com.example.csmail.Client;
    opens com.example.csmail.Client to javafx.fxml, com.google.gson;
}