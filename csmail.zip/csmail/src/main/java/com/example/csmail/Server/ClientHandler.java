package com.example.csmail.Server;

import java.io.*;
import java.lang.reflect.Type;
import java.net.Socket;
import java.nio.Buffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.UserPrincipal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.example.csmail.Client.Mail;
import com.example.csmail.User;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import org.json.simple.*;
import org.json.simple.parser.*;
import com.fasterxml.jackson.core.type.*;
import com.google.gson.*;
import static java.lang.Thread.sleep;
import static com.example.csmail.Client.ClientApplication.user;
public class ClientHandler implements Runnable{

    private Socket client;
    private BufferedReader in;
    private BufferedWriter writer;

    public ClientHandler(Socket clientSocket, BufferedReader in, BufferedWriter out) throws IOException {
        this.client=clientSocket;
        this.in=in;
        this.writer=out;
    }

    @Override
    public void run(){
        Date date = new Date();
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm");
        String formattedDate = myDateObj.format(myFormatObj);
        Calendar calendar = GregorianCalendar.getInstance();
        JSONObject JSONresponse;
        try{
            JSONObject request = (JSONObject) new JSONParser().parse(in.readLine());
            System.out.println("[SERVER]: Richiesta ricevuta : " + request);
            String userMail = (String) request.get("utente");
            switch((String) request.get("request")){
                //Quando il client richiede la disconnessione (nel pannello della MailView)
                case "disconnected":
                    LogController.list.add("["+formattedDate+"] Client ("+userMail+") disconnesso!");
                    this.client.close();
                    break;
                    //Quando il server cade, il client invia la richiesta di riconnessione.
                case "reconnected":
                    //sul log viene aggiunto che il client si è riconnesso.
                    LogController.list.add("["+formattedDate+"] Client ("+userMail+") si è riconnesso con successo!");
                    this.client.close();
                    break;
                    //all'inizio della simulazione ogni client invia richiesta di login
                case "loginrequest":
                    JSONresponse = new JSONObject();
                    ArrayList<User> users = GetUsers();
                    ArrayList<JSONObject> u = new ArrayList<>();
                    for(User us : users){
                        JSONObject temp = new JSONObject();
                        temp.put("name",us.getName());
                        temp.put("cognome",us.getCognome());
                        temp.put("mail",us.getMail());
                        u.add(temp);
                    }
                    JSONresponse.put("users", u);
                    LogController.list.add("["+formattedDate+"]" + " Nuovo client connesso!");
                    //per gestire la mutua esclusione.
                    synchronized (writer){
                        writer.write(JSONresponse.toJSONString());
                        writer.newLine();
                        writer.flush();
                    }
                    this.client.close();
                    break;
                    //Autorefresh in ogni vista MailView per visualizzare le mail,
                    //le riscarica ogni volta con un intervallo di 10 sec
                case "mailrequest":
                    /* Update automatico delle mail */
                    ArrayList<Mail> mailss = GetListMail((String) request.get("utente"));
                    synchronized (writer){
                        writer.write(new Gson().toJson(mailss));
                        writer.newLine();
                        writer.flush();
                    }
                    this.client.close();
                    break;
                    //Caso di gestione eliminazione mail selezionata...
                case "deletemail":
                    Delete(userMail, ((long)request.get("id")));
                    System.out.println("[SERVER] Richiesta Delete da utente : "+request.get("utente"));
                    LogController.list.add("["+formattedDate+"]" + " Delete mail richiesta da : "+request.get("utente"));
                    this.client.close();
                    break;
                    //Caso gestione mail inviata
                case "sendmail":
                    System.out.println("[SERVER] Richiesta INVIO NUOVA MAIL : "+request.toJSONString() +" - Destinata a : " + request.get("destinatari"));
                    SendMail((String)request.get("mittente"), (String)request.get("data"),  (String)request.get("oggetto"), (String)request.get("contenuto"), (String)request.get("destinatari"));
                    LogController.list.add("[ "+formattedDate+"] Richiesta INVIO NUOVA MAIL : "+request.toJSONString() +" - Destinata a : " + request.get("destinatari"));
                    this.client.close();
                    break;
                    //Caso gestione reply ad una mail specifica
                case "replymail":
                    System.out.println("[SERVER] Richiesta di REPLY/REPLY-ALL...");
                    ReplyMail((String)request.get("mittente"), (String)request.get("data"),  (String)request.get("oggetto"), (String)request.get("contenuto"), (String)request.get("destinatari"));
                    LogController.list.add("["+formattedDate+"]" + " Richiesta Reply/Reply-All Mail da: " + request.get("mittente") + " a: " + request.get("destinatari"));
                    this.client.close();
                    break;
                    //Caso gestione forward mail
                case "forwardmail":
                    System.out.println("[SERVER] Richiesta di FORWARD A MAIL SELEZIONATA.");
                    SendMail((String)request.get("mittente"), (String)request.get("data"),  (String)request.get("oggetto"), (String)request.get("contenuto"), (String)request.get("destinatari"));
                    LogController.list.add("["+formattedDate+"]" + " Richiesta Forward mail da: " + request.get("mittente") + " a: " + request.get("destinatari"));
                    this.client.close();
                    break;
                default:
                    break;
            }
        }catch(IOException e){
            System.out.println("Errore : "+e.getMessage());
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
        finally{
            /* Nel finally chiudo tutto : socket, BufferInput e BufferOutput */
            try {
                this.client.close();
                in.close();
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    public static boolean Delete(String user, long id){
        System.out.println("User is : "+user);
        try {
            FileReader reader = new FileReader("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+user);
            //Trasformo in JSON il contenuto del FileReader dal Path fornito e includo tutto in una lista.
            List<Mail> mailz = new Gson().fromJson(reader, new TypeReference<List<Mail>>(){}.getType());
            //Chiudo il FileReader
            reader.close();
            for(int i=0; i < mailz.size();i++){
                if(mailz.get(i).getId() == id){
                    mailz.remove(i);
                    try {
                            FileWriter fileWriter = new FileWriter("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+user);
                            /*
                            * Garantisco che l'accesso al file sia sincronizzato tra i thread
                            * in modo che non ci sia rischio di conflitti in fase di scrittura.
                            * */
                            synchronized (fileWriter){
                                fileWriter.write(new Gson().toJson(mailz));
                                fileWriter.flush();
                                fileWriter.close();
                            }
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                        finally {
                            //Stampa del finally sempre eseguita : comunica che la mail con il ID è stata eliminata.
                            System.out.println("[SERVER]: Mail con id " + id + " rimossa!") ;
                        }
                        break;
                    }
                }
                System.out.println("Mails : "+mailz);
            }catch (Exception e){
            System.out.println("Eccezione Client Handler "+e);
            }
        return false;
    }

    /*
    * Metodo che fa update delle mail.
    * */
    private ArrayList<Mail> GetListMail(String utente) {
        List<Mail> mails=null;
        try {
            Thread.sleep(3000);
            System.out.println("User : "+utente);
            System.out.println("Searching for file with '"+utente+"' as name...");
            Reader reader = Files.newBufferedReader(Paths.get("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+utente));
            /*
             * Poichè sono nel metodo GetListMail, quindi voglio fare update delle mail,
             * uso l'oggetto reader, per leggere la lista di mail dal file presente nella
             * cartella DATA.
             * Garantisco che l'accesso al reader sia sincronizzato tra i thread
             * in modo che non ci sia rischio di conflitti di lettura.
             * */
            synchronized(reader){
                mails = new Gson().fromJson(reader, new TypeReference<List<Mail>>(){}.getType());
                reader.close();
            }
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        return (ArrayList<Mail>) mails;
    }

    private ArrayList<User> GetUsers() throws FileNotFoundException {
        ArrayList<User> users = new ArrayList<User>();
        try {
            JSONParser parser = new JSONParser();
            JSONArray a = (JSONArray) parser.parse(new FileReader("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/Server/users.json"));
            //System.out.println("JSONArray : "+a+"\n");
            for(int i=0; i < a.size(); i++){
                JSONObject jsObj = (JSONObject) a.get(i);
                //System.out.println("Object fetched : "+a.get(i));
                String name = (String) jsObj.get("nome");
                String surname = (String) jsObj.get("cognome");
                String mail = (String) jsObj.get("mail");
                users.add(new User(name, surname, mail));
            }
        } catch (Exception e) {
            System.out.println("An error occurred in GetUsers method: " + e.getMessage());
            e.printStackTrace();
        }
        return users;
    }
    public String SendMail(String mittente, String data, String oggetto, String contenuto, String destinatari) throws FileNotFoundException {
        //Con questo array di stringhe, gestisco la scrittura su file per ogni destinatario.
        String[] recipients = destinatari.split(",");
        String precisi = destinatari;
        List<String> wrong_mail = new ArrayList<>();
        int status=200;
        JSONParser parser = new JSONParser();
        for(int i=0; i < recipients.length; i++){
            long max_id=0;
            recipients[i] = recipients[i].trim();
            System.out.println("Recipients : "+recipients[i]+" at : "+i+" iteration...");
            if(checkEmail(recipients[i])){
                try {
                        System.out.println("Destinatari : { "+destinatari+" }, Recipients : {"+recipients[i]+"}");
                        FileReader reader = new FileReader("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+recipients[i]);
                        System.out.println("Searching for file : '"+recipients[i]+"' ...");
                        if(reader.equals(null)) System.out.println("Reader vuoto!");
                        else{
                            List<Mail> mailList = new Gson().fromJson(reader, new TypeReference<List<Mail>>(){}.getType());
                            BufferedReader br = new BufferedReader(reader);
                            StringBuilder sb = new StringBuilder();
                            String line = null;
                            while((line = br.readLine())!=null){
                                sb.append(line);
                            }
                            //System.out.println("Contenuto in sb = "+sb);
                            if(sb.equals(null) || sb.equals("")){
                                //Create new mail e scrivo nel/i file dei destinatari
                                Mail m = new Mail(1, mittente, precisi, oggetto, contenuto, data);
                                m.setDestinatario(precisi);
                                mailList.add(m);
                                FileWriter fileWriter = new FileWriter("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+recipients[i]);
                                /*
                                 * Garantisco che l'accesso al file sia sincronizzato tra i thread
                                 * in modo che non ci sia rischio di conflitti di scrittura.
                                 * */
                                synchronized (fileWriter){
                                    fileWriter.write(new Gson().toJson(mailList));
                                    fileWriter.flush();
                                    fileWriter.close();
                                }
                                System.out.println("[SERVER]: Mail mandata a :" + m.getDestinatario() + " - Mittente: " + m.getMittente() + " - Contenuto: " + m.getContenuto());
                            }else{
                                for (int j=0; j<mailList.size(); j++){
                                    //System.out.println("ID : "+mailList.get(j).getId());
                                    if(max_id<mailList.get(j).getId()) max_id=mailList.get(j).getId();
                                }
                                Mail mail = new Mail((int)max_id+1, mittente, precisi, oggetto, contenuto, data);
                                mail.setDestinatario(precisi);
                                mailList.add(mail);
                                FileWriter fileWriter = new FileWriter("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+recipients[i]);
                                /*
                                * Garantisco che l'accesso al file sia sincronizzato tra i thread
                                * in modo che non ci sia rischio di conflitti di scrittura.
                                * */
                                synchronized (fileWriter){
                                    fileWriter.write(new Gson().toJson(mailList));
                                    fileWriter.flush();
                                    fileWriter.close();
                                }
                                System.out.println("[SERVER]: Mail mandata a :" + mail.getDestinatario() + " - Mittente: " + mail.getMittente() + " - Contenuto: " + mail.getContenuto());
                            }
                        }
                        reader.close();
                }catch(IOException e){
                    e.printStackTrace();
                }
            }else{
                System.out.println("Status non è 200!");
                status=404;
                //assert wrong_mail != null;
                wrong_mail.add(recipients[i]);
                System.out.println("Wrong mail inserted : "+recipients[i]);
                Alert aError = new Alert(Alert.AlertType.ERROR);
                aError.setTitle("Error Inserting Mail!");
                aError.setContentText("[SERVER]: Mail not found : "+recipients[i]);
                aError.showAndWait();
            }
        }
        JSONObject response = new JSONObject();
        response.put("status", status);
        if(status==404){
            response.put("wrong_mail", new Gson().toJson(wrong_mail));
        }
        try {
            this.writer.write(response.toJSONString());
            this.writer.newLine();
            this.writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "OK";
    }

    public String ReplyMail(String mittente, String data, String oggetto, String contenuto, String destinatari) throws FileNotFoundException {
        String precisi = destinatari;
        String[] recipients = destinatari.split(",");
        List<String> wrong_mail = new ArrayList<>();
        int status=200;
        JSONParser parser = new JSONParser();
        for(int i=0; i < recipients.length; i++){
            long max_id=0;
            recipients[i]=recipients[i].trim();
            //System.out.println("Sono qui prima dell'if!");
            System.out.println("Recipients : "+recipients[i]+" at : "+i+" iteration...");
            User currUser = new User(recipients[i]);
            if(checkEmail(recipients[i])){
                try {
                    System.out.println("Destinatari : { "+precisi+" }");
                    FileReader reader = new FileReader("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+recipients[i]);
                    System.out.println("Searching for file : '"+recipients[i]+"' ...");
                    if(reader.equals(null)) System.out.println("Reader vuoto!");
                    else{
                        List<Mail> mailList = new Gson().fromJson(reader, new TypeReference<List<Mail>>(){}.getType());
                        BufferedReader br = new BufferedReader(reader);
                        StringBuilder sb = new StringBuilder();
                        String line = null;
                        while((line = br.readLine())!=null){
                            sb.append(line);
                        }
                        //System.out.println("Contenuto in sb = "+sb);
                        if(sb.equals(null) || sb.equals("")){
                            //Create new mail e scrivo nel/i file dei destinatari
                            Mail m = new Mail(1, mittente, precisi, oggetto, contenuto, data);
                            m.setDestinatario(precisi);
                            mailList.add(m);
                            FileWriter fileWriter = new FileWriter("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+recipients[i]);
                            /*
                            * Garantisco che l'accesso al file sia sincronizzato tra i thread
                            * in modo che non ci sia rischio di conflitti in fase di scrittura.
                            * */
                            synchronized (fileWriter){
                                fileWriter.write(new Gson().toJson(mailList));
                                fileWriter.flush();
                                fileWriter.close();
                            }
                            System.out.println("[SERVER]: Mail mandata a :" + m.getDestinatario() + " - Mittente: " + m.getMittente() + " - Contenuto: " + m.getContenuto());
                        }else{
                            for (int j=0; j<mailList.size(); j++){
                                //System.out.println("ID : "+mailList.get(j).getId());
                                if(max_id<mailList.get(j).getId()) max_id=mailList.get(j).getId();
                            }
                            Mail mail = new Mail((int)max_id+1, mittente, precisi, oggetto, contenuto, data);
                            mail.setDestinatario(precisi);
                            mailList.add(mail);
                            //User currUser = new User(recipients[i]);
                            FileWriter fileWriter = new FileWriter("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/DATA/"+recipients[i]);
                            /*
                             * Garantisco che l'accesso al file sia sincronizzato tra i thread
                             * in modo che non ci sia rischio di conflitti in fase di scrittura.
                             **/
                            synchronized (fileWriter){
                                fileWriter.write(new Gson().toJson(mailList));
                                fileWriter.flush();
                                fileWriter.close();
                            }
                            System.out.println("[SERVER]: Mail in risposta a :" + mail.getDestinatario() + " - Mittente: " + mail.getMittente() + " - Contenuto: " + mail.getContenuto());
                        }
                    }
                    reader.close();
                }catch(IOException e){
                    e.printStackTrace();
                }
            }else{
                assert wrong_mail != null;
                wrong_mail.add(recipients[i]);
                System.out.println("Wrong mail inserted : "+recipients[i]);
                Alert aError = new Alert(Alert.AlertType.ERROR);
                aError.setTitle("Error Inserting Mail!");
                aError.setContentText("[SERVER]: Mail not found : "+recipients[i]);
                aError.showAndWait();
                status=404;
            }
        }
        JSONObject response=new JSONObject();
        response.put("status", status);
        if (status==404){
            response.put("wrong_mail", new Gson().toJson(wrong_mail));
        }
        try {
            this.writer.write(response.toJSONString());
            this.writer.newLine();
            this.writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "OK";
    }

    //checkMail : method if is in json file
    //La checkMail permette di controllare se la mail inserita è corretta.
    //Altrimenti ritorna FALSE.
    private static synchronized boolean checkEmail(String mail) throws FileNotFoundException {
        FileReader fl = new FileReader("/home/peppe/IdeaProjects/csmail/src/main/java/com/example/csmail/Server/users.json");
        List<User> users = new ArrayList<User>();
        try {
            JSONParser parser = new JSONParser();
            JSONArray user = (JSONArray) parser.parse(fl);
            for(int i=0; i < user.size(); i++){
                JSONObject jsObj = (JSONObject) user.get(i);
                //System.out.println("Object fetched : "+jsObj.get("mail"));
                String name = (String) jsObj.get("nome");
                String surname = (String) jsObj.get("cognome");
                String ownmail = (String) jsObj.get("mail");
                //System.out.println("name : "+name+"\nsurname:"+surname+"\nmail:"+ownmail);
                users.add(new User(name, surname, ownmail));
            }
            fl.close();
        }catch (Exception e){
            System.out.println("Exception in checkMail method : "+e.getMessage()+"!");
        }
        for(int i=0; i<users.size();i++){
                System.out.println("Mail utente : "+users.get(i).getMail());
                if(users.get(i).getMail().equals(mail)){
                    return true;
                }
        }
        return false;
    }
}