package com.example.csmail.Client;

import com.example.csmail.User;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.gson.Gson;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import org.controlsfx.control.Notifications;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.Socket;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SendMailController implements Initializable {
    public static Casella mailbox;
    public static Mail mailForward;
    @FXML
    Button sendmail;
    @FXML
    Label mittente;
    @FXML
    TextField destinatario, destinatari;
    @FXML
    TextField object;
    @FXML
    TextField oggetto;
    @FXML
    Text contenuto;
    @FXML
    TextArea content;
    public void setObject(String oggetto) {
        this.object.setText(oggetto);
    }

    public void setDestinatario(String destinatario) {
        this.destinatario.setText(destinatario);
    }

    public void setMittente(String mittente) {
        this.mittente.setText(mittente);
    }
    public TextArea getContent() {
        return content;
    }

    public void setContent(String content){
        this.content.setText(content);
    }

    public void setContenuto(String contenuto){
        this.contenuto.setText("Contenuto Mail : "+contenuto);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
    }

    /*
    * Prende il bottone del sendMail quando si vuole inviare la mail a qualcuno
    * degli utenti pre-registrati
    */
    @FXML
    public void sendMail(ActionEvent event){
        Socket socket;
        BufferedWriter writer;
        BufferedReader reader;
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        String formattedDate = myDateObj.format(myFormatObj);
        JSONObject request = new JSONObject();
        JSONParser p = new JSONParser();
        String recipients = destinatario.getText();
        System.out.println("Recipients : "+recipients);
        JSONObject response = new JSONObject();
        StringBuilder sb = new StringBuilder();
        int num_recipients = recipients.split(",").length;
        String[] destinatari = recipients.split(",");
        for(String dest : destinatari){
            System.out.println("[CLIENT] Destinatario : "+dest);
        }
        if (!syntaxMails(destinatari)) return;
        request.put("request", "sendmail");
        request.put("mittente", this.mailbox.getUser().getMail());
        request.put("data", formattedDate);
        request.put("oggetto",object.getText());
        request.put("contenuto", content.getText());
        request.put("destinatari", recipients.toString());
        String line = null;
        try{
            socket = new Socket("localhost", 8182);
            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            synchronized (writer){
                writer.write(request.toJSONString());
                writer.newLine();
                writer.flush();
            }
            System.out.println("[CLIENT]: Richiesta di invio nuova mail mandata...");

            while((line = reader.readLine()) != null){
                sb.append(line);
            }
            if(sb.length() == 0){
                String status = "\"status\""+" : 404";
                sb.append("{"+status+"}");
            }
            //else
            System.out.println("StringBuilder contains : "+sb.toString());
            response = (JSONObject) p.parse(String.valueOf(sb));
            System.out.println("Response Contiene : "+response);
            long status = (Long)response.get("status");
            System.out.println("Response status = "+status);
            System.out.println("Response contiene : "+response);
            //LATO CLIENT POSSO AVERE QUESTI STATI : 200 - SUCCESS, 404 - MAIL(S) ERRATA/E, 400 - SERVER OFFLINE
            if((long)response.get("status")==200){
                Alert aConfirm = new Alert(Alert.AlertType.CONFIRMATION);
                aConfirm.setTitle("Email Sent Successfully");
                aConfirm.setContentText("Email sent correctly to receiver!");
                aConfirm.showAndWait();
            }
            if((long)response.get("status")==404){
                //ArrayList<String> wrongmail = new Gson().fromJson((String) response.get("wrong_mail"), new TypeReference<List<String>>(){}.getType());
                Alert aWrong = new Alert(Alert.AlertType.WARNING);
                aWrong.setTitle("ERROR : Email Not Sent Successfully");
                aWrong.setContentText("Email Not Correct!");
                aWrong.showAndWait();
            }
            if((long)response.get("status")==400){
                Alert aWrong = new Alert(Alert.AlertType.ERROR);
                aWrong.setTitle("Client Mail Error "+response.get("status"));
                aWrong.setContentText("Server offline, il client proverà a riconnettersi automaticamente.");
                aWrong.showAndWait();
            }
        }catch(ConnectException connectException){
            Alert a = new Alert(Alert.AlertType.ERROR);
            a.setTitle("Errore "+response.get("status"));
            a.setContentText("Errore connessione!");
            a.showAndWait();
            Runnable reconnect = new Reconnection(sendmail);
            Thread t=new Thread(reconnect);
            t.start();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    /*
    * Reply in questa classe rappresenta l'azione attribuita al bottone presente
    * nel form per rispondere sia come reply che come replyAll, dipende dal bottone
    * premuto in precedenza però.
    */
    @FXML
    public void Reply(ActionEvent event){
        Socket socket;
        BufferedWriter writer;
        BufferedReader reader;
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        String formattedDate = myDateObj.format(myFormatObj);
        JSONObject request = new JSONObject();
        String recipients = destinatario.getText();
        JSONObject response = new JSONObject();
        int num_recipients = recipients.split(",").length;
        System.out.println("recipients : "+recipients);
        String[] destinatari = recipients.split(",");
        for(String dest : destinatari){
            System.out.println("[CLIENT] Destinatario : "+dest);
        }
        if (!syntaxMails(destinatari)) return;
        request.put("request", "replymail");
        request.put("mittente", this.mailbox.getUser().getMail());
        request.put("data", formattedDate);
        request.put("oggetto",object.getText());
        request.put("contenuto", content.getText());
        request.put("destinatari", recipients.toString());
        try {
            socket=new Socket("localhost", 8182);
            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            synchronized (writer){
                writer.write(request.toJSONString());
                writer.newLine();
                writer.flush();
            } //dopo ciò viene automaticamente rilasciato l'oggetto 'lock'.
            System.out.println("[CLIENT]: Richiesta di reply mail mandata...");
            StringBuilder sb = new StringBuilder();
            String line = null;
            while((line = reader.readLine()) != null){
                sb.append(line);
            }
            //Se sb non ha nulla allora di default l'errore è 404 ovvero mail errata/e inserite!
            if(sb.length() == 0){
                String status = "\"status\""+" : 404";
                sb.append("{"+status+"}");
            }
            System.out.println("StringBuilder contains : "+sb.toString());
            JSONParser p = new JSONParser();
            response = (JSONObject) p.parse(String.valueOf(sb));
            System.out.println("Response contiene : "+response);
            if((Long)response.get("status")==200){
                Alert aConfirm = new Alert(Alert.AlertType.CONFIRMATION);
                aConfirm.setTitle("Email Sent Successfully");
                aConfirm.setContentText("Email Replied correctly to receiver!");
                aConfirm.showAndWait();
            }else if((Long)response.get("status")==404){
                //ArrayList<String> wrongmail = new Gson().fromJson((String) response.get("wrong_mail"), new TypeReference<List<String>>(){}.getType());
                Alert aWrong = new Alert(Alert.AlertType.WARNING);
                aWrong.setTitle("ERROR : Email Not Sent Successfully");
                aWrong.setContentText("Email Not Correct!");
                aWrong.showAndWait();
            }else if((Long)response.get("status")==400){
                Alert aWrong = new Alert(Alert.AlertType.ERROR);
                aWrong.setTitle("Client Mail Error "+response.get("status"));
                aWrong.setContentText("Server offline, il client proverà a riconnettersi automaticamente.");
                aWrong.showAndWait();
            }
        }catch(ConnectException connectException){
            Alert aReconn = new Alert(Alert.AlertType.ERROR);
            aReconn.setTitle("Errore : "+response.get("status"));
            aReconn.setContentText("Errore connessione!");
            aReconn.showAndWait();
            Runnable reconnect = new Reconnection(sendmail);
            Thread t=new Thread(reconnect);
            t.start();
        }catch (Exception e){
            System.out.println("Eccezione generica : "+e.getMessage());
        }
    }

    //Lato Client effettuo un controllo sulla sintassi, se c'è qualche mail errata
    //si visualizza un alert aError altrimenti se riconosciuto tra le mail presenti
    //invia correttamente la mail al/ai destinatario/i.
    private boolean syntaxMails(String[] destinatari) {
        Pattern pattern = Pattern.compile("[a-zA-Z]+\\.[a-zA-Z]+@mail\\.com");
            for(String destinatario : destinatari){
                Matcher matcher = pattern.matcher(destinatario.trim());
                if(!matcher.matches()){
                    System.out.println("[CLIENT]: Mail inserita errata : " + destinatario);
                    Alert aError = new Alert(Alert.AlertType.ERROR);
                    aError.setTitle("Syntax Error");
                    aError.setContentText("Mail inserita errata : "+destinatario+"!\nDeve rispettare la sintassi 'nome.cognome@mail.com'!");
                    aError.showAndWait();
                    return false;
                }
            }
        return true;
    }

    /*
    * Gestisce il bottone di Forward presente nel form
    * per inoltrare la mail selezionata
    */
    @FXML
    public void Forward(ActionEvent actionEvent) {
        Socket socket;
        BufferedWriter writer;
        BufferedReader reader;
        LocalDateTime myDateObj = LocalDateTime.now();
        DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        String formattedDate = myDateObj.format(myFormatObj);
        JSONObject request = new JSONObject();
        String recipients = destinatari.getText();
        JSONObject response = new JSONObject();
        int num_recipients = recipients.split(",").length;
        String[] destinatari = recipients.split(",");
        System.out.println("[CLIENT] Destinatari in pos 0 : "+destinatari[0]);
        String addToContenuto = "----- Forwarded Message ------\nDa: <"+mailForward.getMittente()+">\nA: <"+this.mailbox.getUser().getMail()+">\nContenuto:"+mailForward.getContenuto()+"\nDate:"+mailForward.getDate();
        if (!syntaxMails(destinatari)) return;
        request.put("request", "forwardmail");
        request.put("mittente", this.mailbox.getUser().getMail());
        request.put("data", formattedDate);
        request.put("oggetto", mailForward.getOggetto());
        request.put("contenuto", "Contenuto Mail : \n"+addToContenuto);
        request.put("destinatari", recipients);
        try {
            socket = new Socket("localhost", 8182);
            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            synchronized (writer){
                writer.write(request.toJSONString());
                writer.newLine();
                writer.flush();
            }
            System.out.println("[CLIENT]: Richiesta INOLTRO nuova mail a '"+recipients+"' mandata...");
            StringBuilder sb = new StringBuilder();
            String line = null;
            while((line = reader.readLine()) != null){
                sb.append(line);
            }
            //Se sb non ha nulla allora di default l'errore è 404 ovvero mail errata/e inserite!
            if(sb.length() == 0){
                String status = "\"status\""+" : 404";
                sb.append("{"+status+"}");
            }
            System.out.println("StringBuilder contains : "+sb.toString());
            JSONParser p = new JSONParser();
            response = (JSONObject) p.parse(String.valueOf(sb));
            System.out.println("Response contiene : "+response);
            System.out.println("------ [TEST] ------");
            if((Long)response.get("status")==200){
                Alert aConfirm = new Alert(Alert.AlertType.CONFIRMATION);
                aConfirm.setTitle("Email Sent Successfully");
                aConfirm.setContentText("Email sent correctly to receiver!");
                aConfirm.showAndWait();
            }else if((Long)response.get("status")==404){
                //ArrayList<String> wrongmail =new Gson().fromJson((String) response.get("wrong_mail"), new TypeReference<List<String>>(){}.getType());
                Alert aError = new Alert(Alert.AlertType.WARNING);
                aError.setTitle("ERROR : Email Not Sent Successfully");
                aError.setContentText("Email Not Correct!");
                aError.showAndWait();
            }else if((Long)response.get("status")==400){
                Alert aReconn = new Alert(Alert.AlertType.ERROR);
                aReconn.setTitle("Errore "+response.get("status"));
                aReconn.setContentText("Server offline, il client proverà a riconnettersi automaticamente.");
                aReconn.showAndWait();
            }
        }catch (ConnectException connectException){
            Alert aReconn = new Alert(Alert.AlertType.ERROR);
            aReconn.setTitle("Errore "+response.get("status"));
            aReconn.setContentText("Errore connessione!");
            aReconn.showAndWait();
            Runnable reconnect = new Reconnection(sendmail);
            Thread t=new Thread(reconnect);
            t.start();
        }catch (Exception e){
            System.out.println("Eccezione generica : "+e);
        }
    }
}
