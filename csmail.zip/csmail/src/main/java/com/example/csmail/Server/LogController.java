package com.example.csmail.Server;

import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class LogController implements Initializable {
    @FXML
    ListView<String> messageL;
    public static ObservableList<String> list;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
            try{
                    list = FXCollections.observableArrayList(new ArrayList<>());
                    list.addListener((ListChangeListener<String>) change -> {
                        while(change.next()){
                            if(change.wasAdded()){
                                for(String str : change.getAddedSubList()){
                                    synchronized (str){
                                        try{
                                            messageL.getItems().add(str);
                                        }catch(Exception e){
                                            System.out.println("Errore in LogController : "+e.getMessage());
                                        }
                                    }
                                }
                                messageL.refresh();
                            }else if(change.wasRemoved()){
                                messageL.refresh();
                            }
                        }
                    });
            }catch(IllegalStateException e){
                e.printStackTrace();
            }
    }
}
