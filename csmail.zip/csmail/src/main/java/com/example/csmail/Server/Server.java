package com.example.csmail.Server;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class Server extends Application implements Runnable{
    static ExecutorService fixedPool = Executors.newFixedThreadPool(5);
    boolean online;
    @Override
    public void start(Stage stage) throws Exception {
           Thread t = new Thread(this);
           t.start();
           Parent root = FXMLLoader.load(getClass().getResource("/fxml/server.fxml"));
           stage.setTitle("Server Log");
           stage.setScene(new Scene(root));
           stage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void run() {
        List<Socket> socketList = new ArrayList<>();
        ServerSocket serversocket = null;
        //Al momento dell'accensione del server,
        try {
            serversocket = new ServerSocket(8182);
        }
        catch (IOException e){
            System.out.println("IOException: errore in serversocket port 8182.");
        }
        try{
            online = true;
            while(online){
                //Accetto i clients
                Socket client = serversocket.accept();
                //Apro lo stream lettura e scrittura
                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
                //Avvio un clientThread di classe ClientHandler, che metterà in comunicazione
                //i clients con il server.
                ClientHandler clientThread = new ClientHandler(client, in, out);
                fixedPool.execute(clientThread);
                //SocketList ogni volta aggiunge un client nuovo.
                socketList.add(client);
            }
        }catch(IOException e){
            try {
                System.out.println("Closing ServerSocket!\n");
                serversocket.close();
            }catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }
    }
}