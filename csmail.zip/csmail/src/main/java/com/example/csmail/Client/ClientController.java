package com.example.csmail.Client;
import com.example.csmail.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;
import org.json.simple.*;
import org.json.simple.parser.*;
//import org.controlsfx.control.Notifications;

//ClientController è un LoginController
//Fetcha i dati da un file json contenente tre utenti.
//Si connette poi al mail visualizer per visualizzare le mail.
public class ClientController implements Initializable{

    Socket socket;
    BufferedReader bufferedReader;
    BufferedWriter bufferedWriter;

    ArrayList<User> users = new ArrayList<>();
    @FXML
    private Button btnEnter;
    @FXML
    private ListView<User> lista;
    @FXML
    protected void EnterClick(ActionEvent e)throws IOException{
            User utenteSelezionato = lista.getFocusModel().getFocusedItem();
            Window scene = lista.getScene().getWindow();
            Stage stage = (Stage) scene.getScene().getWindow();
            stage.close();
            //Creazione nuova finestra
            System.out.println("[CLIENT]: Accesso effettuato "+ utenteSelezionato.getMail());
            ClientApplication.user = utenteSelezionato;
            Stage stage2 = new Stage();
            FXMLLoader loader = new FXMLLoader((getClass().getResource("/fxml/listview.fxml")));
            Parent root = loader.load();
            Text mymail = (Text) root.lookup("#mymail");
            mymail.setText(utenteSelezionato.getMail());
            stage2.setTitle("Mail Visualizer");
            stage2.setScene(new Scene(root));
            stage2.show();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Accesso effettuato correttamente!");
            alert.setContentText("Utente :"+utenteSelezionato.getMail());
            alert.showAndWait();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
            try{
                socket = new Socket("localhost", 8182);
                bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                JSONObject request = new JSONObject();
                request.put("request", "loginrequest");
                bufferedWriter.write(request.toJSONString());
                bufferedWriter.newLine();
                bufferedWriter.flush();
                System.out.println("[Client] : Richiesta Login Inviata!");
                String users = bufferedReader.readLine();
                System.out.println("Utenti : "+users);
                ArrayList<User> u = new ArrayList<>();
                JSONParser parser = new JSONParser();
                JSONObject json = (JSONObject) parser.parse(users);
                JSONArray ja = (JSONArray) json.get("users");
                for(int i=0; i < ja.size(); i++){
                   JSONObject user = (JSONObject) ja.get(i);
                   User userF = new User((String)user.get("mail"));
                   u.add(userF);
                }
                System.out.println("Lista utenti : "+u);
                ObservableList<User> userlist;
                userlist = FXCollections.observableArrayList(u);
                this.lista.setItems(userlist);
            }catch(ConnectException e){
                //Nel caso in cui la connessione vada persa nella login
                try {
                    ShowErrorConnectionToServer();
                } catch (ConnectException ex) {
                    throw new RuntimeException(ex);
                }
            }catch(IOException | org.json.simple.parser.ParseException e){
                e.printStackTrace();
            }
    }

    public void ShowErrorConnectionToServer() throws ConnectException {
        System.out.println("Connection Error in ClientController!");
        Alert aError = new Alert(Alert.AlertType.ERROR);
        aError.setTitle("Server Not Responding!");
        aError.setContentText("Server OFF!");
        aError.showAndWait();
    }
}
