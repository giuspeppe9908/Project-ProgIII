package com.example.csmail;

import java.util.ArrayList;

public class User {
    private String cognome;
    private String id;
    private String name;
    private String mail;
    private Email email;

    public User(String id, String name){
        this.id = id;
        this.name = name;
        email = new Email(id);//email che contiene l'ID
    }

    public User(String nome, String cognome, String mail) {
        this.name = nome;
        this.cognome = cognome;
        this.mail = mail;
    }

    public User(String mail) {
        this.mail = mail;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Email getEmail() {
        return email;
    }

    public void setEmail(Email email) {
        this.email = email;
    }

    public void setCognome(String cognome){
        this.cognome = cognome;
    }
    public String getCognome() {
        return this.cognome;
    }

    public String getMail() {
        return this.mail;
    }

    @Override
    public String toString() {
        return mail;
    }
}
