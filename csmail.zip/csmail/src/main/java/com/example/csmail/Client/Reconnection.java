package com.example.csmail.Client;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.json.simple.JSONObject;
//import org.controlsfx.control.Notifications;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.UnknownHostException;

public class Reconnection implements Runnable{

    Button deletebutton=null;

    /* Primo Costruttore che contiene il bottone */
    public Reconnection(Button button){
        this.deletebutton=button;
        deletebutton.setDisable(true);
    }

    /* Costruttore vuoto */
    public Reconnection(){
        deletebutton=new Button();
    }

    @Override
    public void run() {
        /* imposto un flag 'offline' = true */
        boolean offline = true;
        /* finché è vero, nel try se il socket è connesso allora imposto il flag a false e chiudo il socket*/
        while(offline){
            try{
                Socket s = new Socket("localhost", 8182);
                if(s.isConnected()){
                    System.out.println("[CLIENT]: Connesso al server!");
                    offline = false;
                    //s.close();
                    deletebutton.setDisable(false);
                }/*else{
                    offline = true;
                    System.out.println("[CLIENT] Client non connesso!");
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
                    JSONObject request = new JSONObject();
                    request.put("request", null);
                    bufferedWriter.write(request.toJSONString());
                    bufferedWriter.newLine();
                    bufferedWriter.flush();
                }*/
            } catch (ConnectException e) {
                //Implemento un alert di error che mi notifica che il server è
                //momentaneamente spento
                System.out.println("[CLIENT]: Tentativo riconnessione al server...");
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        Alert a = new Alert(Alert.AlertType.ERROR);
                        a.setTitle("SERVER OFF!");
                        a.setContentText("The Server is currently OFF!\nWait until it will be up again!\nThanks!");
                        a.show();
                    }
                });
                try{
                    //Tentativo di riconnessione ogni 10 secondi.
                    Thread.sleep(10000);
                    System.out.println("[CLIENT] : Sto tentando nuovamente di riconnettermi...");
                }catch(InterruptedException iexp){
                    iexp.printStackTrace();
                }
            } catch (IOException exp) {
                System.out.println(exp);
                exp.printStackTrace();
            }
        }
    }
}
