package com.example.csmail.Client;

import com.example.csmail.User;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Optional;
import java.util.ResourceBundle;
import org.controlsfx.control.Notifications;
import org.json.simple.JSONObject;

public class MailController implements Initializable, Runnable{
    Casella mailbox;
    @FXML
    ImageView up;
    @FXML
    private TableView<Mail> TableViewMail;
    @FXML
    private TableColumn<Mail, String> ColumnMittente;
    @FXML
    private TableColumn<Mail, String> ColumnContenuto;
    @FXML
    private TableColumn<Mail, String> ColumnData;

    @FXML
    private TableColumn<Mail, String> ColumnOggetto;

    @FXML
    private TableColumn<Mail, String> ColumnDest;
    @FXML
    private Text mymail;
    @FXML
    MenuItem disconnect_account;
    @FXML
    Button sendmail;
    @FXML
    Button replyto;
    @FXML
    Button replyAll;
    @FXML
    Button DeleteButton;
    @FXML
    Button forwardTo;
    static private String ss;
    //Object lock = new Object();
    public void setMyMail(MouseEvent mouseEvent) {
        if(mouseEvent.getClickCount()==2){
            try{
                Stage stage=new Stage();
                FXMLLoader loader = new FXMLLoader((getClass().getResource("/fxml/viewmail.fxml")));
                Parent root=loader.load();
                System.out.println("SetMail : "+TableViewMail.getFocusModel().getFocusedItem().getDate());
                ((ViewMailController)loader.getController()).setContent(TableViewMail.getFocusModel().getFocusedItem().getContenuto());
                ((ViewMailController)loader.getController()).setObject(TableViewMail.getFocusModel().getFocusedItem().getOggetto());
                ((ViewMailController)loader.getController()).setMittente(TableViewMail.getFocusModel().getFocusedItem().getMittente());
                ((ViewMailController)loader.getController()).setDestinatario(TableViewMail.getFocusModel().getFocusedItem().getDestinatario());
                ((ViewMailController)loader.getController()).setData(TableViewMail.getFocusModel().getFocusedItem().getDate());
                stage.setTitle("Mail from "+TableViewMail.getFocusModel().getFocusedItem().getMittente());
                stage.setScene(new Scene(root));
                stage.show();
            }catch (Exception e){
                System.out.println("Errore in setMail : "+e.getMessage());
            }
        }
    }

    @Override
    public void run() {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("New Mail Received!");
        a.setContentText("A new mail has been sent to your mail address\nThe sender is : "+this.ss+"\nUpdating your emails...");
        a.showAndWait();
    }
    public void setU(User u) {
        mailbox = new Casella(u);
    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        this.setU(ClientApplication.user);
        System.out.println("[CLIENT] user selected : "+ClientApplication.user);
        //Dopo aver acceduto con l'utente specifico, parte un Thread che prende un runnable
        //dichiarato come MailListener, questo si occupa di aggiornare periodicamente la lista
        //delle mail...
        up.setVisible(false);
        Runnable listner = new MailListener(mailbox, TableViewMail, ColumnMittente, ColumnContenuto, ColumnData, ColumnOggetto, ColumnDest);
        Thread t = new Thread(listner);
        //Questo setDaemon(true) è fondamentale poichè ogni qual volta chiudo la MailView del client selezionato, non chiede più l'update delle mail
        t.setDaemon(true);
        t.start();
        up.setVisible(true);
    }

    public static void MailRicevuta(String mittente){
        ss=mittente;
        Platform.runLater(new MailController());
    }
    /* Metodo che esegue l'operazione di disconnessione del client di posta */
    @FXML
    public void DisconnectAccount(ActionEvent actionEvent) throws Exception {
        Socket socket = null;
        BufferedWriter bufferedWriter = null;
        BufferedReader bufferedReader = null;
        System.out.println("Tipo evento : "+actionEvent.getEventType());
        try {
            socket = new Socket("localhost", 8182);
            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            JSONObject request = new JSONObject();
            request.put("request", "disconnected");
            request.put("utente", ClientApplication.user.getMail());
            bufferedWriter.write(request.toJSONString());
            bufferedWriter.newLine();
            bufferedWriter.flush();
            //poi chiudo tutto...
            System.out.println("Chiudo applicazione client...");
            socket.close();
            Platform.exit();
            bufferedReader.close();
            bufferedWriter.close();
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    /*
    * Metodo che esegue l'eliminazione della Mail selezionata dal file dell'utente loggato.
    */
    @FXML
    public void deleteMail(ActionEvent event) {
        Mail mail = TableViewMail.getFocusModel().getFocusedItem();
        Socket socket = null;
        BufferedReader bufferedReader = null;
        BufferedWriter bufferedWriter = null;
        try {
            socket = new Socket("localhost", 8182);
            bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            JSONObject request = new JSONObject();
            request.put("request", "deletemail");
            request.put("utente", ClientApplication.user.getMail());
            request.put("id", mail.getId());
            //Utilizzo del synchronized per evitare che la risorsa bufferedWriter venga contesa.
            synchronized (bufferedWriter){
                //Trasformo richiesta come formato stringa JSON
                bufferedWriter.write(request.toJSONString());
                bufferedWriter.newLine();
                bufferedWriter.flush();
                //rimuovo dalla mailbox la mail selezionata
                this.mailbox.removeMail(mail);
            }
            //Rimuovo dalla TableViewMail
            TableViewMail.getItems().remove(mail);
        }catch (ConnectException ex){} catch (UnknownHostException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        finally{
            try{
                socket.close();
                bufferedWriter.close();
                bufferedReader.close();
            }catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    /*
    * Metodo che permette al client connesso di mandare una mail ad un altro utente pre-registrato.
    * */
    @FXML
    public void NewMail(ActionEvent actionEvent) throws IOException {
        SendMailController.mailbox = mailbox;
        Stage stage = new Stage();
        FXMLLoader loader = new FXMLLoader((getClass().getResource("/fxml/sendmail.fxml")));
        Parent root=loader.load();
        stage.setTitle("- New Mail -");
        stage.setScene(new Scene(root));
        stage.setResizable(false);
        stage.show();
    }

    /*
    * Metodo che permette di effettuare la ReplyAll ad una mail specifica selezionata dalla
    * casella di posta elettronica.
    * */
    @FXML
    public void ReplyAll(ActionEvent event) throws IOException{
        SendMailController.mailbox = mailbox;
        Mail mail = TableViewMail.getFocusModel().getFocusedItem();
        Stage stage = new Stage();
        FXMLLoader loader = new FXMLLoader((getClass().getResource("/fxml/replytomail.fxml")));
        Parent root=loader.load();
        stage.setTitle("- Reply All to this Mail -");
        SendMailController.mailForward = mail;
        System.out.println("Nella casella mail è loggato : "+mailbox.getUser().getMail());
        String mittenteNuovo = "", destinatarioFinale = "";
        String destinatarioNuovo[];
        System.out.println("Mittente  mail : "+mail.getMittente());
        System.out.println("Destinatario mail : "+mail.getDestinatario());
        //Se la stringa che contiene i destinatari ne contiene più di 1 allora splitto
        //in un array chiamato destinatarioNuovo le varie mail.
        destinatarioNuovo = mail.getDestinatario().split(",");
        StringBuilder strbuilder = new StringBuilder();
        /*Rimuove eventuali spazi bianchi usando il metodo strip() dell'oggetto String.
        * Se l'indirizzo email corrente corrisponde all'indirizzo email dell'utente della casella di posta (mailbox.getUser().getMail()), la stringa formattata con la lista
        * di destinatari (strbuilder) viene estesa aggiungendo l'indirizzo email del mittente della mail (mail.getMittente()).
        * In caso contrario, la stringa formattata con la lista di destinatari viene estesa aggiungendo l'indirizzo email del destinatario corrente (receiver).
        * Se non è l'ultimo indirizzo email nell'array, viene aggiunta una virgola tra gli indirizzi mail.
        */
        for(int i = 0; i < destinatarioNuovo.length; i++){
            String receiver = destinatarioNuovo[i].strip(); //rimuove gli spazi bianchi
            if(receiver.equals(mailbox.getUser().getMail())){
                strbuilder.append(mail.getMittente());
            }else{
                strbuilder.append(receiver);
            }
            if (i != destinatarioNuovo.length - 1)
                strbuilder.append(",");
        }
        ((SendMailController)loader.getController()).setDestinatario(strbuilder.toString());
        ((SendMailController)loader.getController()).setObject("ReAll: "+mail.getOggetto());
        stage.setScene(new Scene(root));
        stage.show();
    }


    /*
    * Metodo che esegue la Reply ad una mail selezionata dalla propria casella di posta.
    * */
    @FXML
    public void Reply(ActionEvent actionEvent) throws IOException {
        SendMailController.mailbox = mailbox;
        Mail mail = TableViewMail.getFocusModel().getFocusedItem();
        System.out.println("Mail selezionata : "+mail.toString());
        Stage stage = new Stage();
        FXMLLoader loader = new FXMLLoader((getClass().getResource("/fxml/replytomail.fxml")));
        Parent root = loader.load();
        stage.setTitle("- Reply to this Mail -");
        SendMailController.mailForward = mail;
        ((SendMailController)loader.getController()).setDestinatario(mail.getMittente());
        //Qui setto che nell'oggetto della Reply ci sia 'Re:' per evidenziare la reply
        ((SendMailController)loader.getController()).setObject("Re: "+mail.getOggetto());
        stage.setScene(new Scene(root));
        stage.show();
    }

    /*
    * Metodo che esegue Forward di una mail selezionata dalla propria casella di posta.
    * */
    @FXML
    public void Forward(ActionEvent actionEvent) throws IOException {
        SendMailController.mailbox = mailbox;
        Mail mail = TableViewMail.getFocusModel().getFocusedItem();
        System.out.println("Mail selezionata : "+mail.toString());
        SendMailController.mailForward = mail;
        Stage stage = new Stage();
        FXMLLoader loader = new FXMLLoader((getClass().getResource("/fxml/forwardmail.fxml")));
        Parent root=loader.load();
        stage.setTitle("- Forward this Mail -");
        ((SendMailController)loader.getController()).setContenuto(mail.getContenuto());
        stage.setScene(new Scene(root));
        stage.show();
    }
}
