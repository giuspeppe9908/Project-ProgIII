package com.example.csmail.Client;
import com.example.csmail.Server.LogController;
import javafx.application.Platform;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.stage.*;
import org.json.simple.JSONObject;

import java.io.*;
import java.net.*;
import java.util.*;
public class ReconnectController implements Initializable, Runnable{
    Socket s;
    @Override
    public void run() {
            boolean offline = true;
            //while(offline){
                try{
                    s = new Socket("localhost", 8182);
                    if(s.isConnected()){
                        System.out.println("[CLIENT]: Connesso al server!");
                        offline = false;
                        //s.close();
                        Platform.runLater(new ClientApplication());
                    }else{
                        try{
                            Thread.sleep(10000);
                            //Platform.runLater(new ClientApplication());
                        }
                        catch(InterruptedException iexp){
                            iexp.printStackTrace();
                        }
                    }
                } catch (ConnectException e) {
                } catch (IOException exp) {
                    System.out.println(exp);
                    exp.printStackTrace();
                }
            //}
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
