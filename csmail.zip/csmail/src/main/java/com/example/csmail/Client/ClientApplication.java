package com.example.csmail.Client;

import com.example.csmail.User;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class ClientApplication extends Application implements Runnable{
    static Stage mainstage;

    public static User user;
    @Override
    public void start(Stage stage) throws IOException {
            FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/fxml/client.fxml"));
            Parent root2 = loader2.load();
            stage.setTitle("Client");
            stage.setMinHeight(700.00);
            stage.setMinWidth(800.00);
            stage.setScene(new Scene(root2));
            stage.show();
            mainstage = stage;
    }
    public static void main(String[] args) {
        launch();
    }

    @Override
    public void run() {

    }
}
