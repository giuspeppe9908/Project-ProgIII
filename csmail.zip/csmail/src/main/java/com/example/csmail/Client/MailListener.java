package com.example.csmail.Client;

import com.example.csmail.Server.ClientHandler;
import com.example.csmail.Server.LogController;
import com.fasterxml.jackson.core.type.TypeReference;
import com.google.gson.Gson;
import javafx.application.Platform;
import javafx.application.Preloader;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.google.gson.reflect.TypeToken;
public class MailListener implements Runnable{
    Socket socket;
    Casella casella;
    TableView<Mail> TableViewMail;
    TableColumn<Mail,String> ColumnMittente;
    TableColumn<Mail, String> ColumnContenuto;
    TableColumn<Mail, String> ColumnData;
    TableColumn<Mail, String> ColumnOggetto;
    TableColumn<Mail, String> ColumnDest;

    public MailListener(Casella mailbox, TableView<Mail> tableViewMail, TableColumn<Mail, String> columnMittente, TableColumn<Mail, String> columnContenuto, TableColumn<Mail, String> columnData, TableColumn<Mail, String> columnOggetto, TableColumn<Mail,String> columnDest) {
        this.casella = mailbox;
        this.TableViewMail = tableViewMail;
        this.ColumnMittente = columnMittente;
        this.ColumnContenuto = columnContenuto;
        this.ColumnData = columnData;
        this.ColumnOggetto = columnOggetto;
        this.ColumnDest = columnDest;
    }

    @Override
    public void run() {
            //Invio automatico del download delle mail
            //fin quando il client non si disconnette
            BufferedReader bufferedReader = null;
            BufferedWriter bufferedWriter = null;
            List<Mail> mails = null;
            boolean online = true;
            while(online) {
                try {
                    socket = new Socket("localhost", 8182);
                    bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                    JSONObject request = new JSONObject();
                    request.put("request", "mailrequest");
                    request.put("utente", casella.getUser().getMail());
                    System.out.println("Request updating : " + request.toJSONString());
                    bufferedWriter.write(request.toJSONString());
                    bufferedWriter.newLine();
                    bufferedWriter.flush();
                    assert socket.isConnected() && bufferedReader.ready();
                    String s = bufferedReader.readLine();
                    mails = new Gson().fromJson(s, new TypeReference<ArrayList<Mail>>() {
                    }.getType());
                }catch (IOException exp) {
                    //Se sono nel mailListener (quindi ho la View della posta in arrivo, se il server cade, notifico l'errore e faccio runnare un reconnection che ritenterà la connessione al server).
                    System.out.println("[MailListener] says : 'Error during Connection With SERVER!'");
                    //Cade la connessione, ma avvio un Runnable che comincia la riconnessione al Server di ogni client.
                    Runnable reconn = new Reconnection();
                    reconn.run();
                    System.out.println("Client ha ricominciato la connessione al server...");
                    //rimetto la variabile booleana online = true
                    online = true;
                    try {
                        //Riapre la connessione con il server...
                        socket = new Socket("localhost", 8182);
                        //Riapre i canali di comunicazione...
                        //I bufferreader e bufferwriter prendono il flusso dal socket, quindi dal server
                        bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                        JSONObject request = new JSONObject();
                        request.put("request", "reconnected");
                        request.put("utente", casella.getUser().getMail());
                        System.out.println("Request is : " + request.toJSONString());
                        bufferedWriter.write(request.toJSONString());
                        bufferedWriter.newLine();
                        bufferedWriter.flush();
                    }catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                /*
                * Questo frammento di codice (da riga 113 - 141) aggiorna la vista della tabella TableViewMail in base alle nuove
                * email ricevute nella lista mails, verificando se una nuova email è stata ricevuta
                * e chiamando un metodo MailRicevuta per ogni nuova email ricevuta.
                * Inoltre, questo codice aggiorna anche la casella di posta aggiungendo
                * tutte le nuove email alla lista di posta dell'utente che è loggato.
                */
                if (mails != null) {
                    if (TableViewMail.getItems().size() > 0) {
                        for (int j = 0; j < mails.size(); j++) {
                            boolean old_mail = false;
                            for (int i = 0; i < TableViewMail.getItems().size(); i++) {
                                if (TableViewMail.getItems().get(i).toString().equals(mails.get(j).toString())) {
                                    old_mail = true;
                                }
                            }
                            //Il metodo MailRicevuta serve ad aggiornare la vista dell'interfaccia utente
                            //mostrando una notifica (posta come alert nel metodo run()) per indicare che una nuova email è stata ricevuta dal mittente specificato.
                            if (!old_mail) {
                                MailController.MailRicevuta(mails.get(j).getMittente());
                            }
                        }
                    }
                    /*
                    * Pulizia della TableViewMail
                    * */
                    TableViewMail.getItems().clear();
                    /*
                    * Riaggiunta alla casella e alla TableViewMail delle mail nuove.
                    */
                    for (int i = 0; i < mails.size(); i++) {
                        casella.addMail(mails.get(i));
                        TableViewMail.getItems().add(mails.get(i));
                    }
                }
                //Associazione nella TableView di ogni colonna al suo specifico campo delle mail
                ColumnMittente.setCellValueFactory(new PropertyValueFactory<>("mittente"));
                ColumnOggetto.setCellValueFactory(new PropertyValueFactory<>("oggetto"));
                ColumnData.setCellValueFactory(new PropertyValueFactory<>("date"));
                ColumnContenuto.setCellValueFactory(new PropertyValueFactory<>("contenuto"));
                ColumnDest.setCellValueFactory(new PropertyValueFactory<>("destinatario"));
                try {
                    bufferedWriter.close();
                    bufferedReader.close();
                    Thread.sleep(5000);//Aspetto 5 secondi
                    socket.close();//chiudo connessione con il server.
                } catch (IOException e) {
                    System.out.println("Errore di input : " + e.getMessage());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }

}
