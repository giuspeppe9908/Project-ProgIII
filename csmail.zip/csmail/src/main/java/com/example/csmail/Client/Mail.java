package com.example.csmail.Client;
public class Mail {
    private long id;
    private String mittente;
    private String destinatario;
    private String oggetto;
    private String contenuto;
    private String date;

    public String getDate(){
        return date;
    }
    public long getId() {
        return id;
    }

    public String getContenuto() {
        return contenuto;
    }

    public String getOggetto() {
        return oggetto;
    }

    public void setDestinatario(String destinatario){
        this.destinatario = destinatario;
    }
    public String getDestinatario() {
        return this.destinatario;
    }

    public String getMittente() {
        return mittente;
    }

    @Override
    public String toString(){
        return (id + " "+ mittente+ " "+ destinatario+ " "+oggetto+ " "+contenuto+ " "+date);
    }

    public Mail(int id, String mittente, String destinatario, String oggetto, String contenuto, String date ){
        this.id = id;
        this.mittente = mittente;
        this.destinatario = destinatario;
        this.oggetto=oggetto;
        this.contenuto=contenuto;
        this.date=date;
    }
}
